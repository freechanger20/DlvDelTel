package com.tgwipe

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File

class MainActivity : Activity() {

    // Все известные варианты Telegram (Play, сайт, бета, Telegram X)
    private val telegramPackages = listOf(
        "org.telegram.messenger",
        "org.telegram.messenger.web",
        "org.telegram.messenger.beta",
        "org.telegram.messenger.regular",
        "org.thunderdog.challegram"
    )

    // Папки во внутренней памяти, куда Telegram сохраняет файлы
    private val folders = listOf(
        "Telegram",
        "Telegram X",
        "Download/Telegram",
        "Download/Telegram X",
        "Pictures/Telegram",
        "Pictures/Telegram X",
        "Movies/Telegram",
        "Music/Telegram",
        "Documents/Telegram",
        "DCIM/Telegram"
    )

    private lateinit var status: TextView
    private lateinit var button: Button
    private val queue = ArrayDeque<String>()
    private var waitingForStorage = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dp = resources.displayMetrics.density
        val pad = (24 * dp).toInt()

        button = Button(this).apply {
            text = "Стереть Telegram"
            textSize = 22f
            setOnClickListener { onWipeClicked() }
        }
        status = TextView(this).apply {
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, pad, 0, 0)
            text = "Удалит Telegram, его файлы и затем это приложение."
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
            addView(button, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, (120 * dp).toInt()))
            addView(status, LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT))
        }
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        if (waitingForStorage) {
            waitingForStorage = false
            if (hasStorageAccess()) startWipe()
            else status.text = "Нет доступа к файлам. Нажмите кнопку ещё раз и разрешите доступ."
        }
    }

    private fun onWipeClicked() {
        if (hasStorageAccess()) {
            startWipe()
        } else {
            status.text = "Разрешите доступ ко всем файлам и вернитесь назад."
            requestStorageAccess()
        }
    }

    private fun hasStorageAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
            PackageManager.PERMISSION_GRANTED

    private fun requestStorageAccess() {
        waitingForStorage = true
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), REQ_STORAGE)
        }
    }

    // Шаг 1: удаляем папки с файлами Telegram
    private fun startWipe() {
        button.isEnabled = false
        status.text = "Удаляю файлы Telegram…"
        Thread {
            val storage = Environment.getExternalStorageDirectory()
            val targets = folders.map { File(storage, it) } +
                telegramPackages.flatMap {
                    listOf(File(storage, "Android/media/$it"), File(storage, "Android/data/$it"))
                }
            val removed = ArrayList<String>()
            for (dir in targets) {
                if (!dir.exists()) continue
                dir.walkBottomUp().forEach { removed.add(it.absolutePath) }
                dir.deleteRecursively()
            }
            // Обновляем индекс галереи, чтобы удалённые фото/видео не висели в ней
            if (removed.isNotEmpty()) {
                MediaScannerConnection.scanFile(applicationContext, removed.toTypedArray(), null, null)
            }
            runOnUiThread { uninstallTelegram() }
        }.start()
    }

    // Шаг 2: удаляем все установленные варианты Telegram
    private fun uninstallTelegram() {
        queue.clear()
        queue.addAll(telegramPackages.filter { isInstalled(it) })
        uninstallNext()
    }

    private fun uninstallNext() {
        val pkg = queue.removeFirstOrNull()
        if (pkg == null) {
            if (telegramPackages.any { isInstalled(it) }) {
                button.isEnabled = true
                status.text = "Telegram не удалён (удаление отменено). Нажмите кнопку ещё раз."
            } else {
                uninstallSelf()
            }
            return
        }
        status.text = "Удаляю Telegram…"
        val intent = Intent(Intent.ACTION_UNINSTALL_PACKAGE, Uri.parse("package:$pkg"))
            .putExtra(Intent.EXTRA_RETURN_RESULT, true)
        startActivityForResult(intent, REQ_UNINSTALL)
    }

    // Шаг 3: удаляем само это приложение
    private fun uninstallSelf() {
        status.text = "Готово. Удаляю это приложение…"
        val intent = Intent(Intent.ACTION_UNINSTALL_PACKAGE, Uri.parse("package:$packageName"))
            .putExtra(Intent.EXTRA_RETURN_RESULT, true)
        startActivityForResult(intent, REQ_SELF)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_UNINSTALL -> uninstallNext()
            // Если удаление себя прошло, процесс уже завершён; сюда попадаем только при отмене
            REQ_SELF -> {
                button.isEnabled = true
                status.text = "Telegram удалён. Это приложение можно удалить вручную или нажать кнопку снова."
            }
        }
    }

    private fun isInstalled(pkg: String): Boolean = try {
        @Suppress("DEPRECATION")
        packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: PackageManager.NameNotFoundException) {
        false
    }

    companion object {
        private const val REQ_STORAGE = 1
        private const val REQ_UNINSTALL = 2
        private const val REQ_SELF = 3
    }
}
